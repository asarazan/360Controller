/*
 *  chatpadkeys.h
 *  360Controller
 *
 *  Created by Colin on 18/11/2009.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

unsigned char ChatPad2USB(unsigned char input);
